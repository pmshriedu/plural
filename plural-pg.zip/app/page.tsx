import PaymentForm from "@/components/payment-form";
import React from "react";

const Home = () => {
  return <PaymentForm />;
};

export default Home;
